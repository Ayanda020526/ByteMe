// src/services/aiPromptService.js

/**
 * System-level context instruction to guarantee the AI models 
 * return perfectly parsed JSON objects matching our client interface rules.
 */
const SYSTEM_QUIZ_ROLE = `
You are an expert academic AI Quiz Generator engine. 
Your sole task is to generate random quiz variations based on user constraints.
You MUST strictly return your response as a valid JSON array of objects. 
Do not include markdown wrappers like \`\`\`json or trailing text. 

Each object in the array must strictly match this shape:
{
  "id": number,
  "question": "string",
  "options": ["string", "string", "string", "string"],
  "correct": number (0-3 index of the correct option)
}
`;

/**
 * Generates structured variation prompts programmatically.
 */
export const aiPromptService = {
  
  /**
   * Constructs the text prompt string containing dynamic filters.
   * @param {string} topic - E.g., "Data Structures", "Databases", "Mathematics"
   * @param {string} difficulty - "Easy", "Medium", "Hard"
   * @param {number} totalQuestions - Number of quiz elements requested
   */
  buildQuizPrompt(topic, difficulty, totalQuestions = 5) {
    return {
      systemInstruction: SYSTEM_QUIZ_ROLE.trim(),
      userPrompt: `Generate a random variations quiz on the topic of "${topic}".
Difficulty level: ${difficulty}.
Total number of questions required: ${totalQuestions}.
Ensure questions are completely unique, diverse, and cover random core principles of the topic.`
    };
  },

  /**
   * Handles sending the prompt configuration securely to your backend API route layer.
   * Falls back to a clean procedural local backup engine if the API layer goes down.
   */
  async requestDynamicQuiz(topic, difficulty, totalQuestions = 3) {
    const promptConfig = this.buildQuizPrompt(topic, difficulty, totalQuestions);

    try {
      // Replace with your true runtime endpoint route when backend deployment goes live
      const response = await fetch("http://localhost:5000/api/quiz/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(promptConfig),
      });

      if (!response.ok) throw new Error("Server generation failed.");
      
      const data = await response.json();
      return data.questions; // Expecting parsed valid array structure
    } catch (error) {
      console.warn("Backend unavailable. Initializing local procedural generation fallback...");
      return this.getLocalFallbackVariation(topic, difficulty, totalQuestions);
    }
  },

  /**
   * Local Procedural Generator Fallback engine to ensure 
   * your app never breaks during test scenarios when offline.
   */
  getLocalFallbackVariation(topic, difficulty, count) {
    const pool = {
      "Data Structures": [
        { question: "Which data structure follows LIFO?", options: ["Queue", "Array", "Stack", "Tree"], correct: 2 },
        { question: "What is searching time inside balanced BST?", options: ["O(1)", "O(n)", "O(log n)", "O(n²)"], correct: 2 },
        { question: "Which structure is non-linear?", options: ["String", "Graph", "Stack", "Array"], correct: 1 }
      ],
      "Databases": [
        { question: "What does SQL stand for?", options: ["Structured Query Language", "Sequential Queue List", "Simple Query Logic", "State Query Line"], correct: 0 },
        { question: "Which constraint enforces uniqueness?", options: ["NOT NULL", "UNIQUE", "FOREIGN KEY", "CHECK"], correct: 1 }
      ]
    };

    const selectedPool = pool[topic] || pool["Data Structures"];
    // Shuffle and pick requested number of items
    return [...selectedPool].sort(() => 0.5 - Math.random()).slice(0, count);
  }
};
