// src/pages/Dashboard.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function Dashboard() {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  // Metrics Linked State
  const [metrics, setMetrics] = useState({
    quizzesTaken: 0,
    averageScore: 0,
    badgesEarned: 0
  });

  useEffect(() => {
    const savedUser = JSON.parse(localStorage.getItem("user"));
    setUser(savedUser);

    // Read the shared history array populated by the Quiz component
    const localHistory = JSON.parse(localStorage.getItem("quiz_history")) || [];
    
    if (localHistory.length > 0) {
      const totalQuizzes = localHistory.length;
      const sumPercentage = localHistory.reduce((acc, curr) => acc + curr.percentage, 0);
      const avgPercentage = Math.round(sumPercentage / totalQuizzes);
      
      // Award 1 badge for every passed quiz automatically
      const passedCount = localHistory.filter(item => item.result === "Pass").length;

      setMetrics({
        quizzesTaken: totalQuizzes,
        averageScore: avgPercentage,
        badgesEarned: passedCount * 2 // 2 badges per passed quiz module
      });
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/login");
  };

  return (
    <div className="dashboard-container">
      {/* Sidebar Navigation - Full Routing Links Active */}
      <aside className="dashboard-sidebar">
        {/* Replace the static .sidebar-brand block with this responsive video tag container: */}
       <div className="sidebar-brand" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px', marginBottom: '35px' }}>
  <img 
    src="/src/assets/logo.png" 
    alt="Smart Quiz Logo" 
    style={{ width: '32px', height: '32px', objectFit: 'contain' }} 
  />
  <h2 style={{ margin: 0, fontSize: '1.5rem', letterSpacing: '1px', color: 'var(--gold, #d4a017)' }}>
    SMART QUIZ
  </h2>
</div>

        
        <div className="user-profile-summary">
          <span className="user-avatar">👋</span>
          <div className="user-info">
            <p className="username">{user?.username || "Learner"}</p>
            <p className="user-role">{user?.role ? user.role.toUpperCase() : "STUDENT"}</p>
          </div>
        </div>

        <ul className="sidebar-menu">
          <li className="active" onClick={() => navigate("/dashboard")}>🏠 Dashboard</li>
          <li onClick={() => navigate("/quiz")}>📝 Quizzes</li>
          <li onClick={() => navigate("/analytics")}>📊 Analytics</li>
          <li onClick={() => navigate("/history")}>📚 History</li>     {/* <-- Link to History */}
          <li onClick={()=> navigate("/profile")}>👤 Profile</li>
         <li onClick={() => { localStorage.removeItem("user"); navigate("/login"); }} className="logout-item">🚪 Logout</li>
        </ul>
      </aside>

      <main className="dashboard-main-content">
        <header className="dashboard-top-bar">
          <h1>Welcome Back, {user?.username || "Learner"}!</h1>
          <p className="date-indicator">System Overview Dashboard</p>
        </header>

        {/* Dynamic Metric Cards wired into the shared state stream */}
        <section className="metrics-card-grid">
          <div className="metric-card progress-card" onClick={() => navigate("/analytics")} style={{ cursor: 'pointer' }}>
            <h2>{metrics.averageScore}%</h2>
            <p>Learning Progress</p>
            <div className="card-accent-bar progress-bar-accent"></div>
          </div>

          <div className="metric-card generator-card" onClick={() => navigate("/quiz")} style={{ cursor: 'pointer' }}>
            <h2>{metrics.quizzesTaken}</h2>
            <p>Quizzes Completed</p>
            <div className="card-accent-bar generator-bar-accent"></div>
          </div>

          <div className="metric-card badges-card" onClick={() => navigate("/analytics")} style={{ cursor: 'pointer' }}>
            <h2>{metrics.badgesEarned}</h2>
            <p>Badges Earned</p>
            <div className="card-accent-bar badges-bar-accent"></div>
          </div>
        </section>

        <div className="dashboard-content-split">
          {/* Action Link for Recommended Card */}
          <section className="quiz-recommendation-section">
            <h2>Recommended Quiz</h2>
            <div className="recommended-quiz-card">
              <h3>Data Structures Quiz</h3>
              <div className="quiz-meta-tags">
                <span className="tag level-medium">Difficulty: Medium</span>
                <span className="tag questions-count">3 Questions</span>
              </div>
              <button className="dashboard-primary-btn" onClick={() => navigate("/quiz")}>
                Start Quiz
              </button>
            </div>
          </section>

          {/* Quick Analytics Redirection Panel */}
          <section className="performance-analytics-section" onClick={() => navigate("/analytics")} style={{ cursor: 'pointer' }}>
            <h2>Performance Analytics Overview</h2>
            <div className="analytics-skill-item">
              <div className="skill-meta">
                <span>Core Track Mastery</span>
                <span className="skill-percentage">{metrics.averageScore || 0}%</span>
              </div>
              <div className="analytics-progress-wrapper">
                <div className="analytics-progress-fill programming-fill" style={{ width: `${metrics.averageScore || 0}%` }}></div>
              </div>
            </div>
            <p style={{ fontSize: '13px', color: '#6b7280', marginTop: '15px' }}>Click panel to open comprehensive report details →</p>
          </section>
        </div>
      </main>
    </div>
  );
}

export default Dashboard;

