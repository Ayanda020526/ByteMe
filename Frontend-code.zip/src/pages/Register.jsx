// src/pages/Register.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";

function Register() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [role, setRole] = useState("");
  const [studentNumber, setStudentNumber] = useState("");
  const [yearOfStudy, setYearOfStudy] = useState("");


  const handleRegister = (e) => {
    e.preventDefault();

    if (!role) {
      alert("Please select a role.");
      return;
    }

    if (password !== confirmPassword) {
      alert("Passwords do not match");
      return;
    }

    const user = {
      username,
      email,
      role,
      password,
      studentNumber: role === "student" ? studentNumber :"",
      yearOfStudy: role === "student" ? yearOfStudy : ""
    };

    localStorage.setItem("user", JSON.stringify(user));
    alert("Registration successful!");
    navigate("/login");
  };

  return (
    <div className="register-container">
      <div className="left-panel">
        <h1>SMART QUIZ</h1>
        <h2>Join the Smart Learning Revolution</h2>

        <ul className="features">
          <li>Adaptive Learning</li>
          <li>AI Quiz Generator</li>
          <li>Performance Analytics</li>
        </ul>
      </div>

      <div className="right-panel">
        <div className="register-card">
          <h2>Create Account</h2>

          <form onSubmit={handleRegister}>
            <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />

            <input
              type="email"
              placeholder="Email Address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          
            <div className="role-section">
              <label>Select Role</label>
              <div className="role-options">
                <label className={role === "student" ? "selected-role" : ""}>
                  <input
                    type="radio"
                    name="role"
                    value="student"
                    checked={role === "student"}
                    onChange={(e) => setRole(e.target.value)}
                    required
                  />
                  <span>Student</span>
                </label>
                 
                  {role === "student" && (
                    <>
                     <input
                      type="text"
                      placeholder="Student Number (e.g. 230876439)"
                      value={studentNumber}
                      onChange={(e) => setStudentNumber(e.target.value)}
                      className="profile-input-field"
                      required
                     />

                     <div className="form-group-block" style={{ marginBottom: '15px' }}>
                       <select 
                         value={yearOfStudy} 
                         onChange={(e) => setYearOfStudy(e.target.value)} 
                         style={{ width: '100%', padding: '14px', border: '2px solid #ddd', borderRadius: '10px' }}
                         required
                        >
                         <option value="">Select Current Year of Study</option>
                         <option value="1st Year">1st Year (Undergraduate)</option>
                         <option value="2nd Year">2nd Year</option>
                         <option value="3rd Year">3rd Year</option>
                         <option value="Honours">Honours / Postgrad</option>
                       </select>
                     </div>
                   </>
                  )}


                <label className={role === "lecturer" ? "selected-role" : ""}>
                  <input
                    type="radio"
                    name="role"
                    value="lecturer"
                    checked={role === "lecturer"}
                    onChange={(e) => setRole(e.target.value)}
                  />
                  <span>Lecturer</span>
                </label>
              </div>
            </div>

            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />

            <input
              type="password"
              placeholder="Confirm Password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
            />

            <button type="submit" className="primary-gold-btn">
              Register
            </button>
          </form>

          <p>
            Already have an account? <a href="/login" className="login-link">Login</a>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Register;
