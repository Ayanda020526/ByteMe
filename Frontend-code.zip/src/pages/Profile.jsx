// src/pages/Profile.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

function Profile() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [studentNumber, setStudentNumber] = useState("");
 const [yearOfStudy, setYearOfStudy] = useState("");


  useEffect(() => {
    const savedUser = JSON.parse(localStorage.getItem("user"));
    if (savedUser) {
      setUser(savedUser);
      setUsername(savedUser.username || "");
      setEmail(savedUser.email || "");
      setStudentNumber(savedUser.studentNumber || "");
      setYearOfStudy(savedUser.yearOfStudy || "");
    }
  }, []);

  const handleUpdateProfile = (e) => {
    e.preventDefault();
    const updatedUser = { ...user, username, email, studentNumber, yearOfStudy };
    localStorage.setItem("user", JSON.stringify(updatedUser));
    setUser(updatedUser);
    setIsEditing(false);
    alert("Profile configurations updated successfully!");
  };

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/login");
  };

  return (
       <div className="dashboard-container">
             {/* Universal Shared Context Navigation Sidebar Frame */}
             <aside className="dashboard-sidebar">
                    <div className="sidebar-brand"><h2>SMART QUIZ</h2></div>
                       <div className="user-profile-summary">
                         <span className="user-avatar">👋</span>
                         <div className="user-info">
                           <p className="username">{user?.username || "Learner"}</p>
                           <p className="user-role">{user?.role ? user.role.toUpperCase() : "STUDENT"}</p>
                         </div>
                       </div>
                       <ul className="sidebar-menu">
                        <li onClick={() => navigate("/dashboard")}>🏠 Dashboard</li>
                        <li onClick={() => navigate("/quiz")}>📝 Quizzes</li>
                        <li onClick={() => navigate("/analytics")}>📊 Analytics</li>
                        <li onClick={() => navigate("/history")}>📚 History</li>
                        <li className="active">👤 Profile</li>
                        <li onClick={handleLogout} className="logout-item">🚪 Logout</li>
                      </ul>
             </aside>

                {/* Main Focus Window Area */}
                    <main className="dashboard-main-content">
                     <header className="dashboard-top-bar">
                      <h1>Account Profile</h1>
                       <p className="date-indicator">Manage your security credentials and tracking parameters</p>
                     </header>

                        <section className="profile-workspace-layout" style={{ maxWidth: '600px', margin: '30px 0' }}>
                         <div className="quiz-question-container" style={{ background: '#ffffff', padding: '40px' }}>       
                             <div style={{ width: '70px', height: '70px', borderRadius: '50%', background: 'var(--burgundy)', display: 'flex', alignItems: 'center', justifyInContent: 'center', justifyContent: 'center', fontSize: '28px', color: 'white' }}>
                                {username ? username.charAt(0).toUpperCase() : "U"}
                              </div>
                              <div>
                                <h2 style={{ color: 'var(--burgundy)', fontSize: '1.4rem' }}>{username || "Learner"}</h2>
                               <span style={{ fontSize: '12px', background: 'rgba(139, 92, 246, 0.1)', color: 'var(--violet)', padding: '4px 10px', borderRadius: '20px', fontWeight: '700', textTransform: 'uppercase' }}>
                                {user?.role || "STUDENT"}
                              </span>
                             </div>
                         </div>

                          <form onSubmit={handleUpdateProfile}>
                              <div className="form-group-block" style={{ marginBottom: '20px' }}>
                                <label style={{ fontWeight: '600', fontSize: '14px', color: '#4b5563', display: 'block', marginBottom: '6px' }}>Registered Username</label>
                                 <input 
                                   type="text" 
                                   value={username} 
                                   onChange={(e) => setUsername(e.target.value)} 
                                   disabled={!isEditing}
                                   style={{ width: '100%', padding: '12px 16px', border: '2px solid #e5e7eb', borderRadius: '10px', background: isEditing ? '#fff' : '#f9fafb' }}
                                   required
                                 />
                             </div>

                             <div className="form-group-block" style={{ marginBottom: '25px' }}>
                                 <label style={{ fontWeight: '600', fontSize: '14px', color: '#4b5563', display: 'block', marginBottom: '6px' }}>Email Point Address</label>
                                    <input 
                                    type="email" 
                                    value={email} 
                                    onChange={(e) => setEmail(e.target.value)} 
                                    disabled={!isEditing}
                                   style={{ width: '100%', padding: '12px 16px', border: '2px solid #e5e7eb', borderRadius: '10px', background: isEditing ? '#fff' : '#f9fafb' }}
                                   required
                                   />
                                 </div>
                                  
                                  {user?.role === "student" && (
                                       <>
                                         <div className="form-group-block" style={{ marginBottom: '20px' }}>
                                             <label style={{ fontWeight: '600', fontSize: '14px', color: '#4b5563', display: 'block', marginBottom: '6px' }}>Student Identification Number</label>
                                              <input 
                                                type="text" 
                                                value={studentNumber} 
                                                onChange={(e) => setStudentNumber(e.target.value)} 
                                                disabled={!isEditing}
                                                                                    className="profile-input-field"
                                              />
                                         </div>
                                         <div className="form-group-block" style={{ marginBottom: '20px' }}>
                                             <label style={{ fontWeight: '600', fontSize: '14px', color: '#4b5563', display: 'block', marginBottom: '6px' }}>Current Year of Study</label>
                                               <input 
                                                type="text" 
                                                value={yearOfStudy} 
                                                onChange={(e) => setYearOfStudy(e.target.value)} 
                                                disabled={!isEditing}
                                                className="profile-input-field"
                                              />
                                          </div>
                                         </>
                                    )}
                                 <div className="profile-action-controls" style={{ display: 'flex', gap: '15px', borderTop: '1px solid #f3f4f6', paddingTop: '25px' }}>
                                   {!isEditing ? (
                                    <button type="button" className="dashboard-primary-btn" onClick={() => setIsEditing(true)}>
                                    ⚙️ Modify Details
                                  </button>
                                   ) : (
                                   <>
                                   <button type="submit" className="primary-gold-btn" style={{ width: 'auto', padding: '12px 25px' }}>
                                   Save Changes
                                   </button>
                                   <button type="button" className="quiz-nav-btn secondary-btn" onClick={() => { setIsEditing(false); setUsername(user.username); setEmail(user.email); }}>
                                    Cancel
                                    </button>
                                     </>
                                    )}
                                 </div>
                              
                         </form>
                     
                     </section>
                  </main>
        </div>
    );
}

export default Profile;
