// src/pages/Quiz.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { aiPromptService } from "../services/aiPromptService";

function Quiz() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  
  
  // App Generation Modes
  const [quizMode, setQuizMode] = useState("select"); // "select", "loading", "active"
  const [selectedFile, setSelectedFile] = useState(null);
  const [topic, setTopic] = useState("Data Structures");
  const [difficulty, setDifficulty] = useState("Medium");
  const [numQuestions, setNumQuestions] = useState(5); // Default value is 5 questions 

  // Core Quiz Engine States
  const [questions, setQuestions] = useState([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [score, setScore] = useState(0);

  useEffect(() => {
    setUser(JSON.parse(localStorage.getItem("user")));
  }, []);

  const handleFileChange = (e) => {
    setSelectedFile(e.target.files[0]);
  };

  // Triggers the regular AI prompt generation or the document upload parser pipeline
  const handleStartGeneration = async (e) => {
  e.preventDefault();
  setQuizMode("loading");

  const questionCount = parseInt(numQuestions, 10);

  if (selectedFile) {
    // 1. Pack the file safely if a student uploads document notes
    const formData = new FormData();
    formData.append("quizNotes", selectedFile);
    formData.append("difficulty", difficulty);
    formData.append("totalQuestions", questionCount); // Sends chosen quantity to backend

    try {
      const response = await fetch("http://localhost:5000/api/quiz/generate-from-file", {
        method: "POST",
        body: formData,
      });
      const data = await response.json();
      setQuestions(data.questions);
    } catch (err) {
      console.warn("Backend offline. Loading local prompt engine fallback...");
      setQuestions(aiPromptService.getLocalFallbackVariation(topic, difficulty, questionCount));
    }
  } else {
    // 2. Regular topic tracking route with dynamic question numbers
    const data = await aiPromptService.requestDynamicQuiz(topic, difficulty, questionCount);
    setQuestions(data);
  }
  
  setQuizMode("active");
};


  return (
    <div className="dashboard-container">
      {/* Sidebar shell stays locked here */}
      <aside className="dashboard-sidebar">
        {/* Replace the static .sidebar-brand block with this responsive video tag container: */}
          <div className="sidebar-brand" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px', marginBottom: '35px' }}>
  <img 
    src="/src/assets/logo.png" 
    alt="Smart Quiz Logo" 
    style={{ width: '32px', height: '32px', objectFit: 'contain' }} 
  />
  <h2 style={{ margin: 0, fontSize: '1.5rem', letterSpacing: '1px', color: 'var(--gold, #d4a017)' }}>
    SMART QUIZ
  </h2>
</div>


        <ul className="sidebar-menu">
          <li onClick={() => navigate("/dashboard")}>🏠 Dashboard</li>
          <li className="active" onClick={() => navigate("/quiz")}>📝 Quizzes</li>
          <li onClick={() => navigate("/analytics")}>📊 Analytics</li>
          <li onClick={() => navigate("/history")}>📚 History</li>
          <li onClick={()=> navigate("/profile")}>👤 Profile</li>
          <li onClick={() => { localStorage.removeItem("user"); navigate("/login"); }} className="logout-item">🚪 Logout</li>
        </ul>
      </aside>

      <main className="dashboard-main-content">
        {/* MODE 1: Generation Setup Panel with Document Drag Selector */}
        {quizMode === "select" && (
          <div className="quiz-generation-setup-card">
            <h2>Configure Your AI Quiz</h2>
            <p>Choose an overall topic channel or upload your own lecture notes to test yourself.</p>
            
            <form onSubmit={handleStartGeneration}>
              <div className="form-group-block">
                <label>Topic / Area of Focus</label>
                <select value={topic} onChange={(e) => setTopic(e.target.value)} disabled={selectedFile}>
                  <option value="Data Structures">Data Structures</option>
                  <option value="Databases">Database Systems</option>
                  <option value="Programming">Programming Fundamentals</option>
                </select>
              </div>

              {/* BLOCK A: Add the File Upload Dropzone */}
             <div className="document-upload-dropzone">
               <span className="upload-icon">📂</span>
               <label htmlFor="file-picker" className="file-picker-label" style={{ cursor: 'pointer', textDecoration: 'underline' }}>
                 {selectedFile ? `Attached: ${selectedFile.name}` : "Upload Document Notes (.pdf, .txt)"}
               </label>
               <input 
                  type="file" 
                  id="file-picker" 
                  accept=".pdf,.txt" 
                 onChange={(e) => e.target.files.length > 0 && setSelectedFile(e.target.files[0])} 
                 style={{ display: 'none' }}
                />
                {selectedFile && (
                 <button type="button" className="clear-file-btn" onClick={() => setSelectedFile(null)} style={{ color: '#ef4444', border: 'none', background: 'transparent', display: 'block', margin: '5px auto', cursor: 'pointer' }}>
                  Remove file
                  </button>
               )}
             </div>

             {/* BLOCK B: Add the Dynamic Question Count Dropdown */}
             <div className="form-group-block" style={{ marginTop: '15px', display: 'flex', flexDirection: 'column', textAlign: 'left' }}>
              <label style={{ fontWeight: '600', fontSize: '14px', marginBottom: '5px', color: '#4b5563' }}>Number of Questions</label>
              <select value={numQuestions} onChange={(e) => setNumQuestions(e.target.value)} style={{ width: '100%', padding: '12px', border: '2px solid #e5e7eb', borderRadius: '8px' }}>
               <option value="3">3 Questions</option>
               <option value="5">5 Questions</option>
               <option value="10">10 Questions</option>
               <option value="15">15 Questions</option>
             </select>
             </div>

              <button type="submit" className="primary-gold-btn" style={{ marginTop: '20px' }}>
                ✨ Generate AI Quiz Variation
              </button>
            </form>
          </div>
        )}

        {/* MODE 2: Generation Engine Spinner Loader */}
        {quizMode === "loading" && (
          <div className="quiz-question-container" style={{ textAlign: 'center', padding: '60px' }}>
            <h2>🤖 AI Engine Reading Content...</h2>
            <p style={{ marginTop: '10px', color: '#6b7280' }}>Parsing text layout frames and structuring random variants...</p>
          </div>
        )}

        {/* MODE 3: Traditional Active Quiz Presentation Body Frame */}
        {quizMode === "active" && (
          <div>
            <header className="quiz-header-bar">
              <h1>{selectedFile ? "Custom Notes Quiz" : `${topic} Quiz`}</h1>
            </header>
            
            {/* The rest of your existing active questions rendering map block stays identical below... */}
            <div className="quiz-question-container">
               <h2 className="question-text">{questions[currentQuestion]?.question}</h2>
               {/* Options map mapping button controls goes here */}
               <button className="dashboard-primary-btn" onClick={() => setQuizMode("select")}>Exit Quiz</button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default Quiz;


